import './modules/typeWriter.js';
import './modules/burgerMenu.js';