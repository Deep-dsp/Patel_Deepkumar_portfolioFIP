# My Portfolio
![Team Awesome](/images/readImg.png)

### About

This is going to be my portfolio website which will give you all information regarding my profession. It will insights on my background "Who am I ?", skills, technology and tools in which I am proficient, best of work that I have done till now with the description of each project.

This website demostrates mainly for pages.

1. Home Page
    -   It will just show my name and name of the profession.

2. About Page
    -  It will give you information about myself, my studies, my interest, work pipeline etc. and there will be my    `Resume` and `Cover letter` for the people who are interested in hiring me. 

3. Portfolio Page
    - It will show you three of my best graphic design samples and motion graphics demoreel.

4. Contact Us Page
    - This page is for the people who want to contact me for inquiry to clear their doubts.

[My Portfolio Roadmap](https://docs.google.com/document/d/1RuCADiqIzE_wQyVoPUhx2hrhDjB8u9_h79WyZlQUqVM/edit?usp=sharing)

### Languages Used To Create Web Page:

1. javascript 
2. Html
3. Css
4. AJAX
5. JSON

### Web Development Framework:

1. sass 
2. Vue.js 

### Backend Development :

1. Php
2. MySQL
3. PhpMyAdmin

### Typography - Web Development

1. Poppins
  --- Used mostly with the supporting text ---
2. Roboto
  --- Used widely in this project specially with the headings ---
3. Arial
  --- Used for paragraph writing ---
4. Ubuntu
  --- Used for Navigation bar ---



### Tools Used To Create Graphical Elements, Edit Photos and Creating Advertisement Video:

1. Adobe Photoshop
2. Adobe Illustrator
3. Adobe After Effects
4. Adobe Media Encoder
5. Indesign
6. cinema4D


### Typography - Graphic Design & Video

1. Gotham
2. High Tower
3. Impact Regular


### Authors

1. Deepkumar Patel(0953510)

### License

This project is licensed under ***MIT***

© Copyrights Reserved.
